import React from "react";
import { useSelector } from "react-redux";
import { total } from "../utils/helper";

const Info = ({ title, total }) => {
  const carts = useSelector((state) => state.carts);
  //console.log(carts);

  return (
    <div className="text-xl font-semibold">
      <p>{title}</p>
      <p className="text-5xl">{total}</p>
    </div>
  );
};

export default Info;
