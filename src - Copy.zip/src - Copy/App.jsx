import { useSelector } from "react-redux";
import Carts from "./components/Carts";
import Info from "./components/Info";
import Product from "./components/Product";

function App() {
  const { products, carts } = useSelector((state) => {
    return {
      products: state.products,
      carts: state.carts,
    };
  });
  const sum = carts.reduce((acc, o) => acc + parseInt(o.totalPrice), 0);
  const totalItem = carts.reduce((acc, o) => acc + parseInt(o.quantity), 0);
  //console.log("products-", products);
  //console.log("carts-", carts);
  return (
    <div className="bg-gray-50 h-full md:h-screen">
      <div className="grid place-items-center">
        <h1 className="text-gray-900 font-bold text-3xl p-10 underline decoration-purple-500 decoration-4 underline-offset-8 mb-4">
          Shopping Cart
        </h1>
      </div>
      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-12 sm:col-span-12 md:col-span-7 lg:col-span-8 xxl:col-span-8">
          {products.length > 0
            ? products.map((product, index) => (
                <Product key={index} product={product}></Product>
              ))
            : "There is no Products!"}
        </div>
        <div className="col-span-12 sm:col-span-12 md:col-span-5 lg:col-span-4 xxl:col-span-4">
          <div className="bg-white py-4 px-4 shadow-md rounded-lg my-4 mx-4">
            {carts.length > 0
              ? carts.map((cart, index) => (
                  <Carts key={index} cart={cart}></Carts>
                ))
              : "There is no Cart Items!"}

            <div className="flex justify-center items-center text-center">
              <Info title={"Total Item"} total={totalItem}></Info>
            </div>
          </div>
          <div className="bg-white py-4 px-4 shadow-md rounded-lg my-4 mx-4">
            <div className="flex justify-center items-center text-center">
              <Info title={"Total Price"} total={sum}></Info>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
