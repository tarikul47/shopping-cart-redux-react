export const ADD_TO_PRODUCT_IN_CART = "products/addToProductInCart";
export const PRODUCT_STOCK_INCREMENT = "products/productStockIncrement";
export const PRODUCT_STOCK_DECREMENT = "products/productStockDecrement";