import {
  ADD_TO_PRODUCT_IN_CART,
  PRODUCT_STOCK_DECREMENT,
  PRODUCT_STOCK_INCREMENT,
} from "./productsActionTypes";

export const addToProductInCart = (id) => {
  return {
    type: ADD_TO_PRODUCT_IN_CART,
    payload: id,
  };
};
export const productStockIncrement = (id) => {
  return {
    type: PRODUCT_STOCK_INCREMENT,
    payload: id,
  };
};
export const productStockDecrement = (id) => {
  return {
    type: PRODUCT_STOCK_DECREMENT,
    payload: id,
  };
};
