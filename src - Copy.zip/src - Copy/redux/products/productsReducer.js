import {
  ADD_TO_PRODUCT_IN_CART,
  PRODUCT_STOCK_DECREMENT,
  PRODUCT_STOCK_INCREMENT,
} from "./productsActionTypes";

const initialState = [
  {
    pid: 1,
    title: "Asus Vivobook X515MA",
    stock: 2,
    price: 35500,
    quantity: 1,
    totalPrice: 35500,
  },
  {
    pid: 2,
    title: "Dell E1916HV 18.5 Inch",
    stock: 35,
    price: 9300,
    quantity: 1,
    totalPrice: 9300,
  },
  {
    pid: 3,
    title: "Canon Eos 4000D 18MP",
    stock: 72,
    price: 36500,
    quantity: 1,
    totalPrice: 36500,
  },
];

const productsReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_TO_PRODUCT_IN_CART:
      // console.log("add to cart state", state);
      const updateStock = state.map((item) => {
        //console.log("action.payload", action.payload.id);
        //console.log("item id", item.pid);
        if (item.pid === action.payload.pid) {
          //  console.log("yes llo");
          return {
            ...item,
            stock: Number(item.stock) - 1,
          };
        } else {
          return {
            ...item,
          };
        }
      });

      //console.log(state);
      // console.log(updateStock);
      return [...updateStock];

    case PRODUCT_STOCK_INCREMENT:
      const pin = state.find((item) => item.pid === action.payload);
      if (pin.stock > 1) {
        pin.stock = pin.stock - 1;
      }else{
        alert('You can\'t delete the product');
      }
      //console.log("p", p);
      return [...state];

    case PRODUCT_STOCK_DECREMENT:
      const pde = state.find((item) => item.pid === action.payload);
      pde.stock = pde.stock + 1;
      //console.log("p", p);
      return [...state];

    default:
      return [...state];
  }
};

export default productsReducer;
