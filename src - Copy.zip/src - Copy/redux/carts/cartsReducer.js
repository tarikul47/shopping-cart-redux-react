import {
  ADD_TO_CART,
  CART_INCREMENT,
  CART_DECREMENT,
} from "./cartsActionTypes";

const initialState = [
  // {
  //   id: 1,
  //   title: "Asus Vivobook X515MA",
  //   stock: 20,
  //   quantity: 1,
  //   price: 35500,
  //   totalPrice: 1,
  //   pid: 1,
  // },
  // {
  //   id: 2,
  //   title: "Dell E1916HV 18.5 Inch",
  //   stock: 20,
  //   quantity: 1,
  //   price: 35500,
  //   totalPrice: 1,
  //   pid: 2,
  // },
];

const cartsReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_TO_CART:
      // const { pid, title, stock, price } = action.payload;
      const item = action.payload;

      // console.log("item-", item);

      // state check if product already in cart

      // state.map((cart) => {
      //   //console.log(cart.pid === pid);
      //   if (cart.pid === pid) {
      //     console.log(cart.pid === pid);
      //     return {
      //       ...cart,
      //       stock: Number(cart.stock) - 1,
      //     };
      //   } else {
      //     state.push({
      //       //id: 1,
      //       title: title,
      //       stock: stock,
      //       quantity: 1,
      //       price: price,
      //       totalPrice: 1,
      //       pid: pid,
      //     });
      //   }
      // });

      const existItem = state.find((x) => x.pid == item.pid);
      console.log("existingId", existItem);

      if (existItem) {
        if (existItem.stock > 1) {
          existItem.quantity++;
          existItem.totalPrice = existItem.quantity * existItem.price;
        } else {
          alert("You can't delete the product");
        }
        return [...state];
      } else {
        return [...state, item];
      }

    // const newCart = {
    //   id: pid,
    //   title: title,
    //   stock: stock,
    //   quantity: 1,
    //   price: price,
    //   totalPrice: 1,
    // };

    //}

    case CART_INCREMENT:
      console.log("CART_INCREMENT");
      const findCartIn = state.find((item) => item.pid === action.payload);

      if (findCartIn) {
        findCartIn.quantity = findCartIn.quantity + 1;
        findCartIn.totalPrice = findCartIn.quantity * findCartIn.price;
        return [...state];
      } else {
        return [...state];
      }

    case CART_DECREMENT:
      console.log("CART_INCREMENT");
      const findCartDe = state.find((item) => item.pid === action.payload);

      if (findCartDe) {
        findCartDe.quantity = findCartDe.quantity - 1;
        findCartDe.totalPrice = findCartDe.quantity * findCartDe.price;
        return [...state];
      } else {
        return [...state];
      }

    default:
      return [...state];
  }
};
export default cartsReducer;

/**:
 * state = { cartItems: [], shippingAddress: {} }, action
 * 
 const item = action.payload

  const existItem = state.cartItems.find(x => x.product === item.product)

  if(existItem) {
    return  {
        ...state,
        cartItems: state.cartItems.map(x => x.product === existItem.product ? item : x),
    }
    } else {
        return {
            ...state,
            cartItems: [...state.cartItems, item]
        }
        
    }



    export const addToCart = (id, qty) => async (dispatch, getState) => {
    const { data } = await axios.get(`/api/products/${id}`)

    dispatch({
        type: CART_ADD_ITEM,
        payload: {
            product: data._id,
            name: data.name,
            image: data.image,
            price: data.price,
            countInStock: data.countInStock,
            qty
        }
    })

    localStorage.setItem('cartItems', JSON.stringify(getState().cart.cartItems))

}
 */
