export const ADD_TO_CART = "carts/addToCart";
export const CART_INCREMENT = "carts/cartIncrement";
export const CART_DECREMENT = "carts/cartDecrement";
