import {
  ADD_TO_CART,
  CART_INCREMENT,
  CART_DECREMENT,
} from "./cartsActionTypes";

export const addToCart = (value) => {
  return {
    type: ADD_TO_CART,
    payload: value,
  };
};
export const cartIncrement = (value) => {
  return {
    type: CART_INCREMENT,
    payload: value,
  };
};
export const cartDecrement = (value) => {
  return {
    type: CART_DECREMENT,
    payload: value,
  };
};
