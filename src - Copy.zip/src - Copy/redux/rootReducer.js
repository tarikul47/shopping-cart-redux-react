import { combineReducers } from "redux";
import cartsReducer from "./carts/cartsReducer";
import productsReducer from "./products/productsReducer";

const rootReducer = combineReducers({
  products: productsReducer,
  carts: cartsReducer,
});

export default rootReducer;
